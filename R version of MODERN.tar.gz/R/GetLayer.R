# ***************************************************************************
# Name        : GetLayer.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Get the layer that intersects the depth z
#'
#' This function returns the information ralated to the layer that intersect the depth z
#' @param RDF An object of class Inventory
#' @param z The depth at which select the FRN layer
#' @return A list of parameters: zup, zdown, Origin, id
#' @examples
#' zup = c(0,-1,-2,-3)
#' zdown = c(-1,-2,-3,-4.5)
#' FRN = c(100,80,60,30)
#' name = 'Reference Site 1'
#' myRDF = Inventory(zup,zdown,FRN, name)
#' lay = GetLayer(myRDF,-0.8)
#' print(lay)
#' @export

GetLayer <- function(RDF,z) UseMethod("GetLayer")

GetLayer.default <- function(RDF,z){
  val = RDF$Layers[(z<=RDF$Layers[,1]) & (z>=RDF$Layers[,2]),]
  return(val)
}