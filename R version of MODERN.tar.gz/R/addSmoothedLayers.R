# ***************************************************************************
# Name  		 	: addSmoothedLayers.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Add smooth layers
#'
#' This function add several layers to the end of the profile
#' with exponential decrease starting from the deeper value
#' and decreasing up to the depth of the sample profile.
#' @param RDF A Reference Depth Profile object (class "Inventory")
#' @param Depth The depth to add at the bottom of the profile or a FRN total inventory sampling site (class "Inventory")
#' @param NumLay The number of layers to use to calculate the initial value of the smoothed profile (default is 1 = use the deeper layer)
#' @param DEBUG Print intermediate results (default is False)
#' @return A new Reference Depth Profile object (class "Inventory")
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' plot(myRDF)
#' newDepth = 9
#' myRDF.smo = addSmoothedLayers(myRDF,newDepth)
#' plot(myRDF.smo)
#' @export

addSmoothedLayers <- function(RDF,Depth, NumLay=1, DEBUG = F){
  # get the lowest layer thickness from RDF
  n = length(RDF$Layers$zup)
  # check if NumLay is greater then the total number of layer
  if (NumLay > n){
    wmsg = paste('<NumLay> must be lower or equal to the total number of layers: ',n,
                 '\n <NumLay> is automatically set to ', n)
    NumLay = n
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE,
            domain = NULL)
  }


  delta = abs(RDF$Layers$zup[n]-RDF$Layers$zdown[n])
  mindepth = RDF$Layers$zdown[n]
  if (DEBUG) print(paste('mindepth:',mindepth))

  if (class(Depth)=='Inventory'){
    d = GetLayerThickness(Depth)
  }else if (class(Depth)=='numeric'){
    d = Depth
  } else {
    wmsg = paste('Depth must be a number or an Inventory object!')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE,
            domain = NULL)
    return(RDF)
  }

  # get the thickness of the Sample layer
  maxdepth = mindepth-abs(d)
  if (DEBUG) print(paste('maxdepth:',maxdepth))
  newdepths = seq(mindepth,maxdepth,-delta)
  if (DEBUG) print(newdepths)

  # get deeper layer value(s)
  if (DEBUG) print(paste('Num. of deeper layer:',(n-NumLay+1)))
  d = dim(RDF$FRN)
  if (d[2]>1) {
    deepval = apply(RDF$FRN[(n-NumLay):n,],2,mean)
  } else{
    deepval = mean(RDF$FRN[(n-NumLay):n,1])
  }

  if (DEBUG) print(paste('Deepest value:',deepval))

  i = 1
  while (i<length(newdepths)){
    newvalues = deepval*exp(-(i))
    if (DEBUG) print(newvalues)

    # add a new layer
    RDF = SetLayer(RDF, newdepths[i], newdepths[i+1],
                   newvalues, 'smoothed')
    i=i+1
  }

  RDF
}
