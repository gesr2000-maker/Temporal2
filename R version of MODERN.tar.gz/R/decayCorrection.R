# ***************************************************************************
# Name  		 	: decayCorrection.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' @title Decay Correction
#'
#' @description
#' This function updates the FRN inventory considering the physical decay.
#'
#' @seealso
#' See also \url{http://www.turkupetcentre.net/petanalysis/decay.html} for details.
#'
#' @param FRNinv An Inventory class object
#' @param halflife The half-time expressed in seconds or an isotope code
#' @param newTime The new reference time for decay correction (character)
#' @param oldTime The old reference time for decay correction (character, default is FRNinv$refTime)
#' @param timeFormat The time format used to express the time (default is \%Y-\%m-\%d)
#' @return A new FRN depth profile object (class "Inventory")
#' @examples
#' SP = createSamplingProfile(50,30,'Sampling profile')
#' ## the new time is later than old time
#' SP.later = decayCorrection(SP,halflife=951441000,newTime='01/01/2015', oldTime = '01/01/2010',timeFormat = '%d/%m/%Y')
#' print(SP.later)
#' ## the new time is earlier than old time
#' SP.earlier = decayCorrection(SP.later,halflife=951441000,newTime='01/01/2010', oldTime = '01/01/2015',timeFormat = '%d/%m/%Y')
#' print(SP.earlier)
#' @export


decayCorrection <- function(FRNinv,halflife=NA,
                            newTime=NA, oldTime = FRNinv$refTime,
                            timeFormat = '%Y-%m-%d'){
  # check parameters

  if (is.na(halflife)){
    wmsg = paste('<halflife> must be a number or a code from the Isotope list!')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
    return(FRNinv)
  }
  if (is.na(newTime)){
    wmsg = paste('<newTime> must be a character formatted as <timeFormat>!')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
    return(FRNinv)
  }
  if (is.na(oldTime)){
    wmsg = paste('<oldTime> must be a character formatted as <timeFormat>!')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
    return(FRNinv)
  }

  IsotopeList = c('C-11','N-13','O-15','F-18','Cu-62','Cu-64','Ga-68','Ge-68','Br-76','Rb-82')
  Halflife_secList = c(1224,599,123,6588,582,45721.1,40080,2.38E+07,58700,75)

  if (!is.numeric(halflife)){
    halflife = Halflife_secList[IsotopeList == halflife]
  }

  # transform time to seconds
  t1 = as.numeric(strptime(oldTime, timeFormat))
  t0 = as.numeric(strptime(newTime, timeFormat))

  lambda = log(2)/halflife
  FRNinv$FRN = FRNinv$FRN*exp(-lambda*(t0-t1))

  # update average FRN values
  FRNinv$Layers$mean.FRN = apply(FRNinv$FRN,1,mean)
  FRNinv$Layers$sd.FRN = apply(FRNinv$FRN,1,sd)
  FRNinv$Layers$min.FRN = apply(FRNinv$FRN,1,min)
  FRNinv$Layers$max.FRN = apply(FRNinv$FRN,1,max)

  # other metadata
  FRNinv$halfLife = halflife
  FRNinv$refTime = newTime
  FRNinv$timeFormat = timeFormat

  return(FRNinv)
}
