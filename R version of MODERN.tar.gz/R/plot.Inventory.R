# ***************************************************************************
# Name        : plot.Inventory.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Plot reference depth profile data
#'
#' Default plot function for Inventory class object
#' @param x An object of class Inventory
#' @param legend Show legend in the plot area (default = T)
#' @param totInvFRN An object of class SampLayer to be draw in the same plot (default = NULL)
#' @param depthUnit The unit of length abbreviation (default 'cm')
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' plot(myRDF)
#' @export

plot.Inventory <- function(x,legend = T,totInvFRN = NULL,depthUnit = 'cm',main = "Reference depth profile",...){
  # store original settings
  opar = par()

  par(las=1, mar=c(1,5,9,2))

  stats = summary(x)
  #d = GetLayerThickness(x)
  d = 1
  df = x$Layers
  #df = df[ order(-df[,1]), ]
  # set default bar color
  cols = rep('lightgray',stats$len)
  dens = rep(NA,stats$len)
  angs = rep(90,stats$len)
  cols[df$Origin == 'smoothed'] = 'darkgray'
  dens[df$Origin == 'ploughed'] = 10
  dens[df$Origin == 'deposited'] = 20
  angs[df$Origin == 'deposited'] = -10

  maxvalue = stats$FRNmax/d
  minz = stats$zmin

#   if (!is.null(totInvFRN)){
#     #h = GetLayerThickness(totInvFRN)
#     h = 1
#     maxvalue =max(maxvalue,totInvFRN$Layers$max.FRN/h)
#     minz = min(minz,totInvFRN$Layers$zdown)
#   }

  # calculate a rounded maxvalue
  #maxvalue.round = 10^ceiling(log10(maxvalue))
  maxvalue.round = ceiling(maxvalue)
  xticks = pretty(c(0,maxvalue))

  # max depth in case of only 1 layer
  maxz = stats$zmax
  if (stats$len==1){
    minz = 2.5*minz
  }

  plot(NA,NA,
       xlab = NA, ylab = NA, axes = F,
       ylim=c(minz,maxz),
       xlim = c(0,max(xticks)),
       xaxs="i")

  box()

  for (i in seq(1,stats$len,1)){
    #d = abs(df$zdown[i]-df$zup[i])
    d = 1
    # draw the bar
    rect(0, df$zdown[i], df$mean.FRN[i]/d, df$zup[i],
         density = dens[i], angle = angs[i], col = cols[i],
         lty = 'solid', lwd = 1, border = "black")
    # draw the line
    segments(df$min.FRN[i]/d, 0.5*(df$zdown[i]+df$zup[i]),
             df$max.FRN[i]/d, 0.5*(df$zdown[i]+df$zup[i]),
             col = 'black')
    segments(df$min.FRN[i]/d, df$zup[i]-0.2*d, df$min.FRN[i]/d, df$zdown[i]+0.2*d, col = 'black')
    segments(df$max.FRN[i]/d, df$zup[i]-0.2*d, df$max.FRN[i]/d, df$zdown[i]+0.2*d, col = 'black')
  }

  # add sampling site if exists
#   if (!is.null(totInvFRN)){
#     rect(0, totInvFRN$Layers$zdown,
#          totInvFRN$Layers$mean.FRN/h, totInvFRN$Layers$zup,
#          density = NULL, angle = 45, col = NA,
#          lty = 'dashed', lwd = 2, border = "green")
#   }


  # add axes
  axis(2, at = c(df$zup,df$zdown[stats$len]),
       labels = c(df$zup,df$zdown[stats$len]),
       tick = T, line=0)

  axis(3, at = xticks, labels = xticks)

  # add axes labels
#   txt <- bquote("FRN (Bq " ~ m^{-2} ~ .(depthUnit) ~ ''^{-1} ~ ")")
#   mtext(txt,side=3, line =2.3)
  mtext(main,side=3, line = 6.5, font = 2)
  mtext(x$Name,side=3, line =4.5,font = 3)
  mtext(expression(paste("FRN (Bq ",m^{-2},")")),side=3, line =2.3)

  #mtext(paste('Depth (',depthUnit,')',sep = ''),side=2, line =3, las =0)
  mtext('Depth',side=2, line =3, las =0)

  if (legend){
    legend(x = 'bottomright',
           legend=c('measured', 'smoothed', 'ploughed','deposited'),
           angle = c(0,0,90,-10),
           density = c(NA,NA,10,20),
           fill =c('lightgray','darkgray','lightgray'),
           y.intersp = 1
    )
  }

  # restore original settings
  par(mar = opar$mar,las = opar$las)

}
