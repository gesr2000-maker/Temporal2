# ***************************************************************************
# Name    	 	: computeStepFunctionInverseSet.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************


#' Get x from the integral function S, when y is known
#'
#' This function allows you to get the x values that meet to y along a broken line.
#' @param y_val The value at which query the broken line
#' @param nodes A dataframe with two columns that contain x and y values of each point along the broken line.
#' @param DEBUG Print intermediate results (default is False)
#' @return A list of intersection points
#' @examples
#' broken.line = data.frame(c(1,2,3,4),c(5,3,10,1))
#' y_val = 4
#' x.list = .computeStepFunctionInverseSet(y_val,broken.line)
#' print(x.list)
#' @keywords internal


computeStepFunctionInverseSet <- function(y_val,xnodes,ynodes, DEBUG = F){
  # Commment:
  # this function completely differs from the Matlab version but
  # it return the same results for some tests.
  ynodes = data.frame(ynodes)

  n.nodes = length(xnodes)
  n.prof = length(ynodes[1,])
  if (DEBUG) print(paste('n.nodes:',n.nodes))
  if (DEBUG) print(paste('y_val:',y_val))

  y_val0 = rep(as.numeric(y_val),(n.nodes-1))
  y_val1 = matrix(y_val0,ncol=n.prof, byrow=T)
  y_val = data.frame(y_val1)
  # p1 and p2 are the two points that delimitate segments
  xp1 = xnodes[1:(n.nodes-1)]
  xp2 = xnodes[2:n.nodes]
  # repeat xp1 and xp2 to fit yp
  xp1 = data.frame(matrix(rep(xp1,n.prof),ncol=n.prof, byrow=F))
  xp2 = data.frame(matrix(rep(xp2,n.prof),ncol=n.prof, byrow=F))
  dx = xp1-xp2

  yp1 = ynodes[1:(n.nodes-1),]
  yp2 = ynodes[2:n.nodes,]
  dy = yp1-yp2
  m = dy/dx
  q = yp1-m*xp1
  # find intersection, also those that are outside the segments
  x_vals = (y_val - q)/m
  # set to NA intersection  outside the actual segments
  cond_x = (((yp1<=y_val) & (yp2>=y_val))|((yp1>=y_val) & (yp2<=y_val)))
  x_vals[!cond_x]=NA

  return(x_vals)
}
