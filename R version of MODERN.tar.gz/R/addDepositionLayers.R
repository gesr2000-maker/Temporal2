# ***************************************************************************
# Name  		 	: addDepositionLayers.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Add deposition layers
#'
#' This function allows you to add more than one layer over the actual profile.
#' @param RDF A Reference Depth Profile object (class "Inventory")
#' @param newvalue The new value assigned to the new layers
#' @param NumLay The number of layers that composed the deposition depth
#' @return A new Reference Depth Profile object (class "Inventory")
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' plot(myRDF.plo)
#' myRDF.dep = addDepositionLayers(myRDF,55,1)
#' plot(myRDF.dep)
#' @export

addDepositionLayers <- function(RDF, newvalue, NumLay){
  # get the layer thickness
  thickness = abs(RDF$Layers$zup[1]-RDF$Layers$zdown[1])
  # get absolute upper limit
  zmax = max(RDF$Layers$zup)

  for (i in seq(1,NumLay,1)){
    RDF = SetLayer(RDF,zmax+i*thickness,
                   zmax+(i-1)*thickness,
                   newvalue, 'deposited')
  }
  RDF
}