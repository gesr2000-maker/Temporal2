# ***************************************************************************
# Name        : ClearLayer.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Remove overlapping layers from a layers list
#'
#' This function removes undesidered layers. The last inserted win over the oldest.
#' @param layertable A dataframe containing all the necessary informations to define a layer
#' @param DEBUG Print intermediate results (default is False)
#' @return A dataframe containing a rectified list of layers
#' @examples
#' # not for end user
#' @keywords internal

CleanLayer <- function(FRN, DEBUG = F){
  lt = FRN$Layers
  data = FRN$FRN
  names.data = names(data)
  n = length(lt[,1])
  #for (i in seq(1,n-2,1)){
  i = 1
  while (i <(n-1)){
    #get the lower limit of the upper layer
    low.lim.up = lt$zdown[i]
    # get the upper limit of the lower layer
    up.lim.low = lt$zup[i+1]
    low.lim.low = lt$zdown[i+1]
    #print(paste(low.lim.up,'VS',up.lim.low,'VS',low.lim.low))
    # compare and do something
    # check for completely overlapping layer
    if (low.lim.up<low.lim.low){
      # deleted lower layer
      lt = lt[-c(i+1), ]
      data = data[-c(i+1), ]
      # update the number of layer
      n = length(lt[,1])
      # update counter
      i = i-1
    } else{
      # no overlapping, maybe intersecting
      if (low.lim.up<up.lim.low){
        # update upper depth of the lower layer
        lt$zup[i+1] = low.lim.up
      } else {
        # limits are OK, do nothing!
      }
      i = i+1
    }
  }
  # check the last layer
  low.lim.up = lt$zdown[n-1]
  # get the upper limit of the lower layer
  up.lim.low = lt$zup[n]
  low.lim.low = lt$zdown[n]
  if (low.lim.up<low.lim.low){
    # deleted lower layer
    lt = lt[-c(i), ]
    data = data[-c(i+1), ]
  } else{
    # no overlapping, maybe intersecting
    if (low.lim.up<up.lim.low){
      # update lower depth of the upper layer
      lt$zdown[n-1] = up.lim.low
    } else {
      # limits are OK, do nothing!
    }
  }

  # check for zero-thickness layer
  delta  = lt$zup -lt$zdown
  if (DEBUG) print(delta)
  ids = which(delta==0)
  if (DEBUG) print(ids)
  if (length(ids)>0) {
    lt = lt[-c(ids), ]
    data = data[-c(i+1), ]
  }

  FRN$Layers = lt
  # always return to data.frame
  FRN$FRN = data.frame(data)
  names(FRN$FRN) = names.data
  return(FRN)
}
