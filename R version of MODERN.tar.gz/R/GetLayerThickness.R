# ***************************************************************************
# Name        : GetLayerThickness.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Get the average layers thickness
#'
#' This function returns the average layer thicknesses
#' @param RDF An object of class Inventory
#' @return The average thickness of the layers
#' @examples
#' zup = c(0,-1,-2,-3)
#' zdown = c(-1,-2,-3,-4.5)
#' FRN = c(100,80,60,30)
#' name = 'Reference Site 1'
#' myRDF = Inventory(zup,zdown,FRN, name)
#' print(GetLayerThickness(myRDF))
#' @export

GetLayerThickness <- function(RDF){
  tks = RDF$Layers$zup-RDF$Layers$zdown
  return(mean(tks))
}
