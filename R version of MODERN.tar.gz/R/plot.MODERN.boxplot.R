# ***************************************************************************
# Name    	 	: plot.MODERN.boxplot.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Plot the results of MODERN as boxplot
#'
#' This function allows you to show MODERN results as histogram.
#' @param x A MODERN object
#' @return A plot
#' @examples
#' ## not suitable for end user
#' @keywords internal

plot.MODERN.boxplot<- function(x,...){
  # store original settings
  opar = par()

  # plotting design
  layout(matrix(c(1,2,3), 1, 3, byrow = T),
         widths=c(2,2,1), heights=c(1,1,1))
  #par(mfrow = c(1,2))

  # plot the reference profile
  plot(x$refProfile,legend = F,totInvFRN = x$sampProfile)

  # add solution lines
  sols = as.numeric(x$solution[!is.na(x$solution)])
  abline(h = sols, col = 'red',lty ='dotted')

  # plot solution by boxplot
  par(las=1, mar=c(1,3,9,1))

  boxplot(sols,
          ylim = c(min(x$refProfile$Layers$zdown),
                   max(x$refProfile$Layers$zup)),
          yaxt = 'n',
          horizontal = F)

  zmin = min(x$refProfile$Layers$zdown)
  zmax = max(x$refProfile$Layers$zup)
  dz = GetLayerThickness(x$refProfile)

  abline(h = seq(zmin,zmax,dz), col = 'gray',lty ='dotted')

  # add axes labels
  mtext('Results distribution',side=3, line =4.5,font = 3)
  mtext('MODERN',side=3, line =6.5, font = 2)
  if (length(sols)==0) {mtext('No solutions found', side=3, line =2.3, col = 'red')}

  # plot legend in a custom way
  par(las=1, mar=c(1,0,9,0))

  plot(NA,NA,axes = F,
       xlim = c(0,10),
       ylim = c(0,20),
       xlab = NA, ylab = NA, main = NA)

  labs=c('measured', 'smoothed', 'ploughed','deposited')
  angs = c(0,0,90,-10)
  dens = c(NA,NA,10,20)
  cols = c('gray','black','gray','gray')
  b.cols = c('black','black','black','black')
  ltys = c('solid','solid','solid','solid')
  lwds = c(1,1,1,1,2)
  ypos = 19
  dy = 0.6
  y.line = 0.5

  for (i in seq(1,length(labs),1)){
    rect(0.25, ypos,
         1.25, ypos+dy,
         density = dens[i], angle = angs[i], col = cols[i],
         lty = ltys[i], lwd = lwds[i], border = b.cols[i])
    text(2, ypos+0.5*dy, labels = labs[i], pos = 4)
    ypos = ypos-(dy+y.line)
  }

  # add lines
  labs = c('solution')
  types = c('l')
  ltys = c(3)
  cols = c('red')
  for (i in seq(1,length(labs),1)){
    lines(c(0,1.5),c(ypos+0.5*dy,ypos+0.5*dy),
          type = types[i], col = cols[i], lty = ltys[i])
    text(2, ypos+0.5*dy, labels = labs[i], pos = 4)
    ypos = ypos-(dy+y.line)
  }

  # restore original settings
  par(mfrow = opar$mfrow,mar = opar$mar,las = opar$las)

}
