# ***************************************************************************
# Name  		 	: createSamplingProfile.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Create Sampling Profile
#'
#' This function creates the inventory profile of the sampling site
#' composed by an unique layer of total FRN value FRNinv.
#' The layer extends from zero (top) to the depth equal to the thickness.
#' @param FRNinv A FRN value (only one is accepted)
#' @param thickness The thickness of the layer
#' @param name The name of the site
#' @param isotope The isotope code used as tracer
#' @param halfLife The time required for a quantity of the isotope to reduce to half its initial value
#' @param samplingTime A character representing the date-time of sampling
#' @param falloutTime A character representing the date-time of fall-out
#' @param timeFormat A character representing the date-time format (default \%Y-\%m-\%d)
#' @param massDepth The area density of the soil (in kg m^-2)
#' @return A new FRN depth profile object (class "Inventory")
#' @examples
#' mySP = createSamplingProfile(14.27, 10, 'Sampling site 1')
#' @export

createSamplingProfile <- function(FRNinv,thickness,name,
                                  isotope = NA,halfLife = NA, falloutTime = NA,
                                  refTime = NA,timeFormat = '%Y-%m-%d',
                                  massDepth = NA){
  # always transform to data.frame
  FRNinv = data.frame(FRNinv)
  n.lay = dim(FRNinv)[1]
  n.prof = dim(FRNinv)[2]
  # check the number of FRNinv: only one is accepted
  if ((n.lay>1) & (n.prof>1)){
    wmsg = paste('2D table of FRN is provided, only the first row will be used!')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE,
            domain = NULL)
    FRNinv = FRNinv[1,]
  }
  if ((n.lay>1) & (n.prof==1)){
    wmsg = paste('List of FRN is provided, they will be used as belonging to the same layer!')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE,
            domain = NULL)
    FRNinv = t(FRNinv)
    # always tranform to a data.frame
    FRNinv = data.frame(FRNinv,row.names = c(1))
    names(FRNinv) = paste('FRN',seq(1,n.lay),sep='')
  }

  #FRNinv = FRNinv/thickness
  RDF = Inventory(0,-thickness,FRNinv, name, origin = 'measured',
                  isotope,halfLife,falloutTime,
                  refTime, timeFormat,
                  massDepth)
  return(RDF)

}
