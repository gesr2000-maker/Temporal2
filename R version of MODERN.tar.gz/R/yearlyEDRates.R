# ***************************************************************************
# Name  		 	: yearlyEDRates.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' @title Erosion/Deposition rates
#'
#' @description
#' This function transforms the erosion or the deposition rate from length unit
#' to ton per hectar per year.
#'
#' @seealso
#' TODO
#'
#' @param rates The rate(s) of erosion/deposition expressed in unit length
#' @param massDepth The mass depth (kg m^-2)
#' @param sampleDepth The depth of the sampling profile (the same unit of rates)
#' @param samplingTime The time of measurement (character)
#' @param falloutTime The time for comparison (character)
#' @param timeFormat The time format used to express the time (default is \%Y-\%m-\%d)
#' @return The yearly soil losses or gains (t ha^-1 yr^-1)
#' @examples
#' ## a simple example
#' myHeigthSolutions = c(-7.8,-3,-9)
#' myMassDepth = 110
#' mySampleDepth = 15
#' mySamplingTime = '2007'
#' myFalloutTime = '1954'
#' myRates = yearlyEDRates(myHeigthSolutions,
#'                myMassDepth,mySampleDepth,
#'                mySamplingTime,myFalloutTime)
#' print('Yearly soil losses or gains (t ha^-1 yr^-1):')
#' print(myRates)
#'
#' ## an example passing a list of parameters
#' myHeigthSolutions = c(3,-4)
#' myMassDepth = c(110,80)
#' mySampleDepth = c(15,10)
#' mySamplingTime = c('2015','2000')
#' myFalloutTime = c('1986','1963')
#' myRates = yearlyEDRates(myHeigthSolutions,
#'          myMassDepth,mySampleDepth,
#'          mySamplingTime,myFalloutTime)
#'
#'print('Yearly soil losses or gains (t ha^-1 yr^-1):')
#'print(myRates)
#'
#' @export


yearlyEDRates <- function(rates,massDepth,sampleDepth,
                          samplingTime, falloutTime,
                          timeFormat = '%Y'){
  if (class(rates)== 'MODERN'){
    ratesToUse = rates$solution
  }else{
    ratesToUse = as.numeric(rates)
  }

  # extract year from time
  t1 = as.numeric(format(strptime(samplingTime, timeFormat),'%Y'))
  t0 = as.numeric(format(strptime(falloutTime, timeFormat),'%Y'))

  Y = 10*(ratesToUse*massDepth)/(sampleDepth*(t1-t0))

  #if (class(rates)== 'MODERN') Y = sapply(Y,function(x) unique(x[!is.na(x)]))

  return(Y)
}
