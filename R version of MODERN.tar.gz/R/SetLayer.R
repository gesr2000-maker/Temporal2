# ***************************************************************************
# Name        : SetLayer.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Set a new layer in the Inventory object
#'
#' This function add or replace a layer
#' @param RDF An object of class Inventory
#' @param zup The upper limit of the layer
#' @param zdown The lower limit of the layer
#' @param FRN The value of the FRN inventory
#' @param origin A tag to trace the origin of the information (default is an empty string)
#' @return An object of class Inventory
#' @examples
#' zup = c(0,-1,-2,-3)
#' zdown = c(-1,-2,-3,-4.5)
#' FRN = c(100,80,60,30)
#' name = 'Reference Site 1'
#' myRDF = Inventory(zup,zdown,FRN, name)
#' newRDF = SetLayer(myRDF,0.5,0,40,'test')
#' @export

SetLayer <- function(RDF, zup, zdown, FRN, origin = '', DEBUG = F) UseMethod("SetLayer")

SetLayer.default <- function(RDF, zup, zdown, FRN, origin = '', DEBUG = F){
  df = RDF$Layers
  data = RDF$FRN
  maxid = max(df$id)
  # update statistics
  FRN = data.frame(matrix(FRN, nrow = 1))
  names(FRN) = names(data)
  data = rbind(data,FRN)
  # some statistics of the new layer
  mean.FRN = mean(as.numeric(FRN))
  sd.FRN = sd(as.numeric(FRN))
  min.FRN = min(as.numeric(FRN))
  max.FRN = max(as.numeric(FRN))

  df = rbind(df,data.frame(zup,zdown,id = (maxid+1),mean.FRN,sd.FRN,min.FRN,max.FRN, Origin = origin))
  neworder = order(-df$zup,-df$id)
  df = df[neworder,]
  data = data[neworder,]
  RDF$Layers = df
  RDF$FRN = data.frame(data)
  names(RDF$FRN) = names(FRN)
  RDF = CleanLayer(RDF)
  RDF
}
