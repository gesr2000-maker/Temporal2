# ***************************************************************************
# Name    	 	: plot.MODERN.hist.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************


#' Plot the results of MODERN as histogram
#'
#' This function allows you to show MODERN results as boxplot.
#' @param x A MODERN object
#' @return A plot
#' @examples
#' ## not suitable for end user
#' @keywords internal

plot.MODERN.hist <- function(x,...){
  # store original settings
  opar = par()

  # plotting design
  layout(matrix(c(1,2,3), 1, 3, byrow = T),
         widths=c(2,2,1), heights=c(1,1,1))
  #par(mfrow = c(1,2))

  # plot the reference profile
  plot(x$refProfile,legend = F,totInvFRN = x$sampProfile)

  # add solution lines
  sols = as.numeric(x$solution[!is.na(x$solution)])
  abline(h = sols, col = 'red',lty ='dotted')

  # plot solution by histogram
  par(las=1, mar=c(1,3,9,1))

  myHist = hist(sols, breaks = seq(min(x$Sfunction$X),max(x$Sfunction$X),1), plot = F)
  max.count = max(myHist$counts)


  # calculate a rounded maxvalue
  n.d = nchar(as.character(round(max.count)))-1
  maxvalue.round = (10^n.d)*ceiling(max.count/(10^n.d))
  step = round(maxvalue.round/10)
  if (step == 0) step = 1

  plot(NA,NA,axes = F,
       xlim = c(0,maxvalue.round),
       ylim = c(min(x$refProfile$Layers$zdown),max(x$refProfile$Layers$zup)),
       xlab = NA, ylab = NA, main = NA,
       xaxs="i")

  box()

  axis(3, at = seq(0,maxvalue.round,step),
       labels = seq(0,maxvalue.round,step))

  # add axes labels
  mtext('Abs. frequency', side=3, line =2.3)

  mtext('Count for 1 cm depth',side=3, line =4.5,font = 3)
  mtext('Results distribution',side=3, line =6.5, font = 2)

  for (i in seq(1,length(myHist$counts),1)){
    # draw the bar
    rect(0, myHist$breaks[i], myHist$counts[i], myHist$breaks[i+1])
  }

  # plot legend in a custom way
  par(las=1, mar=c(1,0,9,0))

  plot(NA,NA,axes = F,
       xlim = c(0,10),
       ylim = c(0,20),
       xlab = NA, ylab = NA, main = NA)

  labs=c('measured', 'smoothed', 'ploughed','deposited','sample')
  angs = c(0,0,90,-10)
  dens = c(NA,NA,10,20,NA)
  cols = c('gray','black','gray','gray',NA)
  b.cols = c('black','black','black','black','green')
  ltys = c('solid','solid','solid','solid','dashed')
  lwds = c(1,1,1,1,2)
  ypos = 19
  dy = 0.6
  y.line = 0.5

  for (i in seq(1,length(labs),1)){
    rect(0.25, ypos,
         1.25, ypos+dy,
         density = dens[i], angle = angs[i], col = cols[i],
         lty = ltys[i], lwd = lwds[i], border = b.cols[i])
    text(2, ypos+0.5*dy, labels = labs[i], pos = 4)
    ypos = ypos-(dy+y.line)
  }

  # add lines
  labs = c('solution')
  types = c('l')
  ltys = c(3)
  cols = c('red')
  for (i in seq(1,length(labs),1)){
    lines(c(0,1.5),c(ypos+0.5*dy,ypos+0.5*dy),
          type = types[i], col = cols[i], lty = ltys[i])
    text(2, ypos+0.5*dy, labels = labs[i], pos = 4)
    ypos = ypos-(dy+y.line)
  }

  # restore original settings
  par(mfrow = opar$mfrow,mar = opar$mar,las = opar$las)

}