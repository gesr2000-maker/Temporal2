# ***************************************************************************
# Name    	 	: plot.MODERN.single.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************


#' Plot the results of MODERN as single points
#'
#' This function allows you to show MODERN results as single points over S function.
#' @param x A MODERN object
#' @return A plot
#' @examples
#' ## not suitable for end user
#' @keywords internal

plot.MODERN.single <- function(x,main = "Reference depth profile",...){
  # store original settings
  opar = par()

  # plotting design
  layout(matrix(c(1,2,3), 1, 3, byrow = T),
         widths=c(2,2,1), heights=c(1,1,1))
  #par(mfrow = c(1,2))

  # plot the reference profile
  plot(x$refProfile,legend = F,totInvFRN = x$sampProfile, main = main)

  # add solution lines
  sols = as.numeric(x$solution[!is.na(x$solution)])
  if (length(sols)>0){
    abline(h = sols, col = 'red',lty ='dotted')
  }

  # plot S data
  par(las=1, mar=c(1,3,9,1))

  # calculate a rounded maxvalue
  # consider also the FRN target
  max.value = max(c(as.numeric(x$Sfunction$G1),as.numeric(x$FRNtarget)))
  xticks = pretty(c(0,max.value))

  plot(NA,NA,axes = F,
       xlim = c(0,max(xticks)),
       ylim = c(min(x$refProfile$Layers$zdown),max(x$refProfile$Layers$zup)),
       xlab = NA, ylab = NA, main = NA,
       xaxs="i")

  box()

  axis(3, at = xticks, labels = xticks)

  # add axes labels
  mtext(expression(paste("FRN (Bq ",m^{-2},")")),
        side=3, line =2.3)

  mtext('S(x) = F(x+d) - F(x)',side=3, line =4.5,font = 3)
  mtext('Integral function S',side=3, line =6.5, font = 2)

  # add S function lines
  points(x$Sfunction$G1,-x$Sfunction$X, type = 'o')

  # add solution lines
  abline(v = x$FRNtarget, col = 'red')
  if (length(sols)>0){
    abline(h = sols, col = 'red',lty ='dotted')
    points(x$FRNtarget,sols,
           pch = 20, col = 'red')
  }

  # plot legend in a custom way
  par(las=1, mar=c(1,0,9,0))

  plot(NA,NA,axes = F,
       xlim = c(0,10),
       ylim = c(0,20),
       xlab = NA, ylab = NA, main = NA)

  labs=c('measured', 'smoothed', 'ploughed','deposited')
  angs = c(0,0,90,-10)
  dens = c(NA,NA,10,20,NA)
  cols = c('gray','black','gray','gray')
  b.cols = c('black','black','black','black')
  ltys = c('solid','solid','solid','solid')
  lwds = c(1,1,1,1)
  ypos = 19
  dy = 0.6
  y.line = 0.5

  for (i in seq(1,length(labs),1)){
    rect(0.25, ypos,
         1.25, ypos+dy,
         density = dens[i], angle = angs[i], col = cols[i],
         lty = ltys[i], lwd = lwds[i], border = b.cols[i])
    text(2, ypos+0.5*dy, labels = labs[i], pos = 4)
    ypos = ypos-(dy+y.line)
  }

  # add lines
  labs = c('S function',
           paste(x$sampProfile$Name,x$FRNtarget),
           'solution')
  types = c('o','l','l')
  ltys = c(1,1,3)
  cols = c('black','red','red')
  for (i in seq(1,length(labs),1)){
    lines(c(0,1.5),c(ypos+0.5*dy,ypos+0.5*dy),
           type = types[i], col = cols[i], lty = ltys[i])
    text(2, ypos+0.5*dy, labels = labs[i], pos = 4)
    ypos = ypos-(dy+y.line)
  }

  # restore original settings
  par(mfrow = opar$mfrow,mar = opar$mar,las = opar$las)

}
