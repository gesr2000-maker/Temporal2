# ***************************************************************************
# Name    	 	: MODERN.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Apply MODERN model
#'
#' This function allows you to compare the reference profile with sample site inventory
#' and return the depth of soil lost or gained.
#' @param refProfile An object of class Inventory
#' @param sampProfile An object of class inventory (with only one layer!)
#' @return A MODERN object that store all the solutions
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' mySL = createSamplingProfile(68,10,'mysite')
#' myMOD = MODERN(myRDF,mySL)
#' plot(myMOD)
#' @export


MODERN <- function(refProfile,sampProfile, DEBUG = F){
  # Check if reference times differ
  t.ref = as.numeric(strptime(refProfile$refTime, refProfile$timeFormat))
  t.samp = as.numeric(strptime(sampProfile$refTime, sampProfile$timeFormat))

  if (is.na(t.ref)){
    wmsg = paste('Reference time <refTime> of the reference profile is NA')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
  }

  if (is.na(t.samp)){
    wmsg = paste('Reference time <refTime> of the sampling profile is NA')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
  }

  if ((!is.na(t.ref)) & (!is.na(t.samp))){
    if (t.ref!=t.samp){
      wmsg = paste('Reference time <refTime> of the reference profile (',
                   refProfile$refTime,
                   ') differs from reference time <refTime> of the Sampling profile (',
                   sampProfile$refTime,
                   ')')
      warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
    }
  }

  # match sampling site FRNs with refProfile number of profiles
  n.prof = dim(refProfile$FRN)[2]
  n.lay = dim(refProfile$FRN)[1]
  n.samp = dim(sampProfile$FRN)[2]

  # If you are lucky, n.samp = n.prof
  # else adjust dimensions
  pts <- proc.time()
  if (n.samp < n.prof){
    dummy = data.frame(rep(as.numeric(sampProfile$FRN),n.prof))
    dummy = data.frame(t(dummy))
    dummy = dummy[1,1:n.prof]
    dummy = data.frame(dummy, row.names = c(1))
    names(dummy) = paste('FRN',seq(1,n.prof),sep='')
    sampProfile$FRN = dummy
  }
  if (n.samp > n.prof){
    # TODO: enlarge data.frame
    dummy = data.frame(rep(refProfile$FRN,n.samp))
    dummy = dummy[,1:n.samp]
    dummy = data.frame(dummy, row.names = seq(1,n.lay,1))
    names(dummy) = paste('FRN',seq(1,n.samp),sep='')
    refProfile$FRN = dummy
  }
  pte <- proc.time()
  diff = as.numeric(pte-pts)
  if (DEBUG) print(paste("processing time of <adjust dimensions> is",diff[3]))

  # calc cumulative function
  pts <- proc.time()
  cumG = computeCumG(refProfile)
  pte <- proc.time()
  diff = as.numeric(pte-pts)
  if (DEBUG) print(paste("processing time of <computeCumG> is",diff[3]))
  h = GetLayerThickness(refProfile)

  # calc what we want to find
  d = GetLayerThickness(sampProfile)
  #FRNtarget = sampProfile$FRN*d
  FRNtarget = sampProfile$FRN

  # now create S function
  pts <- proc.time()
  S = createS(-cumG[,1],cumG[,2:length(cumG[1,])],d,h)
  pte <- proc.time()
  diff = as.numeric(pte-pts)
  if (DEBUG) print(paste("processing time of <createS> is",diff[3]))

  # now find the answer
  if (length(S)>1){
    pts <- proc.time()
    intersects = -computeStepFunctionInverseSet(FRNtarget,S[,1],S[,2:length(S[1,])])
    pte <- proc.time()
    diff = as.numeric(pte-pts)
    if (DEBUG) print(paste("processing time of <computeStepFunctionInverseSet> is",diff[3]))
    names(intersects) = names(refProfile$FRN)
  } else {
    intersects = NA
  }
  

  # initialize the MODERN object
  MOD = list()
  MOD$refProfile = refProfile
  MOD$sampProfile = sampProfile
  MOD$cumG = cumG
  MOD$h = h
  MOD$d = d
  MOD$FRNtarget = FRNtarget
  MOD$Sfunction = S
  MOD$solution = intersects
  class(MOD) = 'MODERN'

  return(MOD)
}
