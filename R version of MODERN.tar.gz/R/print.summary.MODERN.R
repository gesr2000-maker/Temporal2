# ***************************************************************************
# Name        : print.summary.MODERN.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Print statistics
#'
#' Print some statistics (number of layer, min and max depth, min and max FRN)
#' of the inventory profile in readable way.
#' @param x An object of class Inventory
#' @examples
#' TODO
#' @export


print.summary.Inventory <- function(x,...){
  cat(paste('Number of solutions:', x$nOfSolutions))
  cat(paste('\nNumber of outliers:', x$nOfOutliers))
  cat(paste('\nMin value:', x$minSol))
  cat(paste('\nMax value:', x$maxSol))
  cat(paste('\nMean value:', x$meanSol))
  cat(paste('\nStand deviation:', x$sdSol))
  cat('\nQuantile:')
  print(solStat)
}
