# ***************************************************************************
# Name        : Inventory.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Create a FRN depth profile object (Class Inventory)
#'
#' This function initializes an object of class Inventory
#' that stores the FRN inventory of each layer
#' and other metadata of the profile
#' @param zup The upper limits of the layers
#' @param zdown The lower limits of the layers
#' @param FRN A single value or a list of Fallout RadioNuclides, FRN, inventory
#' @param name The name of the place
#' @param origin The source of the profile (default is "measured")
#' @param isotope The isotope code used as tracer
#' @param halfLife The time required for a quantity of the isotope to reduce to half its initial value
#' @param falloutTime A character representing the date-time of fall-out (default is NA)
#' @param refTime A character representing the date-time of reference (e.g. sampling time)
#' @param timeFormat A character representing the date-time format (default \%Y-\%m-\%d)
#' @param massDepth The area density of the soil (in kg m^-2)
#' @return A new FRN depth profile object (class "Inventory")
#' @examples
#' zup = c(0,-1,-2,-3)
#' zdown = c(-1,-2,-3,-4.5)
#' FRN = c(100,80,60,30)
#' name = 'Reference Site 1'
#' myRDF = Inventory(zup,zdown,FRN, name)
#' @export

Inventory <- function(zup,zdown,FRN,name,origin = 'measured',
                      isotope = NA,halfLife = NA, falloutTime = NA,
                      refTime = NA, timeFormat = '%Y-%m-%d',
                      massDepth = NA) UseMethod("Inventory")

Inventory.default <- function(zup,zdown,FRN,name,origin = 'measured',
                              Isotope = NA,halfLife = NA, falloutTime = NA,
                              refTime = NA,timeFormat = '%Y-%m-%d',
                              massDepth = NA){
  zup = as.numeric(zup)
  zdown = as.numeric(zdown)
  n.layers = length(zup)
  # always transform to a data.frame object
  FRN = data.frame(matrix(FRN, nrow = n.layers))
  n.prof = dim(FRN)[2]
  names(FRN) = paste('FRN',seq(1,n.prof),sep ='')
  # make statistics
  mean.FRN = apply(FRN,1,mean)
  sd.FRN = apply(FRN,1,sd)
  min.FRN = apply(FRN,1,min)
  max.FRN = apply(FRN,1,max)

  Origin = rep(origin,n.layers)
  id = seq(1,n.layers,1)
  RDF = list()
  RDF$Layers = data.frame(zup,zdown,id,mean.FRN,sd.FRN,min.FRN,max.FRN,Origin)
  RDF$Name = name
  RDF$FRN = FRN
  # other metadata
  RDF$Isotope = Isotope
  RDF$halfLife = halfLife
  RDF$falloutTime = NA
  if (!is.na(falloutTime)) RDF$falloutTime = strptime(falloutTime,timeFormat)
  RDF$refTime = NA
  if (!is.na(refTime)) RDF$refTime = strptime(refTime,timeFormat)
  RDF$timeFormat = timeFormat
  RDF$massDepth = massDepth
  class(RDF) = 'Inventory'
  RDF
}
