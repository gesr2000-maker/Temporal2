# ***************************************************************************
# Name    	 	: createS.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Create nodes of function S
#'
#' This function allows you to create nodes of function S.
#' @param x_ext A list of x values
#' @param G_ext A list of cumulative values
#' @param d The depth of the sample layer
#' @param h The thickness of the layer in the Reference Depth Profile
#' @param DEBUG Print intermediate results
#' @return A nodes list of the integral function S
#' @examples
#' x.vals = -c(1,2,3,4,5,6,7,8)*3
#' y.vals = (x.vals)^2
#' d.SampLay = 10
#' h.RefLay = 3
#' nodes.S = .createS_mod(x.vals,y.vals,d.SampLay,h.RefLay)
#' print(nodes.S)
#' @keywords internal

createS <- function(x_ext,G_ext,d,h, DEBUG = F){
  G_ext = data.frame(G_ext)
  xmin = min(x_ext)
  xmax = max(x_ext)
  n.prof = length(G_ext[1,])
  n.lay = length(x_ext)

  if (DEBUG){
    print(paste('xmin',xmin))
    print(paste('xmax',xmax))
    print(paste('n. of profiles',n.prof))
    print(paste('n. of layers',n.lay))
    print(paste('Sampling thickness:',d))
    print(paste('Reference thickness:',h))
  }
  
  # check if you have enough depth
  if (xmax<=d){
    wmsg = paste('The thickness of the reference profile (',
                 xmax,
                 ') is lower than or equal to the thickness of the sampling profile (',
                 d,
                 ').\nPlease add more layers to the reference profile.')
    warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE, domain = NULL)
    return(NA)
  }
  
  # extend x_ext to cover all dimension of G_ext
  x_ext = data.frame(matrix(rep(x_ext,n.prof),ncol=n.prof, byrow=F))
  # calculate m and q
  xp1 = x_ext[1:(n.lay-1),]
  yp1 = G_ext[1:(n.lay-1),]
  xp2 = x_ext[2:n.lay,]
  yp2 = G_ext[2:n.lay,]
  m = (yp1-yp2)/(xp1-xp2)
  q = yp1-m*xp1
  # create x1 and x2
  # x_1sta: "first element of 3-Series Through -d in [x_emin,x_emax]":
  p = xmin+(1:h-1)
  x_1sta = p[((p+d) %% h)==0]
  x_1sta = min(x_1sta)
  # nodes x_1 are all x's in definition range of S, which are elements of
  # 3-series through -d:
  x1 = seq(x_1sta,xmax-d,h)#  are not multiples of h ->
  x1 = c(x1,seq(xmin,xmax-d,h))
  x1 = sort(x1,decreasing = T)
  #x1 = data.frame(matrix(rep(x1,n.prof),ncol=n.prof, byrow=F))
  x2 = x1+d
  # get intersections
  i = 1
  # initialize the data.frame of the results
  G = data.frame(matrix(rep(NA,n.prof),ncol=n.prof, byrow=F))
  names.of.G = c('X',paste('G',seq(1,n.prof),sep =''))
  names(G) = names.of.G[2:(n.prof+1)]

  while(i<=length(x1)){
    if (DEBUG) print(paste('test',i,'val',x1[i],'and',x2[i]))
    G1 = m*x1[i]+q
    G2 = m*x2[i]+q
    cond_x1 = (((xp1<=x1[i]) & (xp2>=x1[i]))|((xp1>=x1[i]) & (xp2<=x1[i])))
    cond_x2 = (((xp1<=x2[i]) & (xp2>=x2[i]))|((xp1>=x2[i]) & (xp2<=x2[i])))
    G1 = G1[cond_x1]
    G2 = G2[cond_x2]
    # rebuild data.frame
    n.G1 = length(G1)/n.prof
    #G1 = unique(data.frame(matrix(G1,ncol = n.prof, byrow = F)))
    G1 = data.frame(matrix(G1,ncol = n.prof, byrow = F), row.names=seq(1,n.G1))
    G1 = sapply(G1,mean)
    G1 = data.frame(matrix(G1,ncol = n.prof, byrow = F), row.names=1)
    names(G1)=names.of.G[2:(n.prof+1)]

    n.G2 = length(G2)/n.prof
    #G2 = unique(data.frame(matrix(G2,ncol = n.prof, byrow = F)))
    G2 = data.frame(matrix(G2,ncol = n.prof, byrow = F), row.names=seq(1,n.G2))
    G2 = sapply(G2,mean)
    G2 = data.frame(matrix(G2,ncol = n.prof, byrow = F), row.names=1)
    names(G2)=names.of.G[2:(n.prof+1)]

    # store differences
    G = rbind(G,G2-G1)
    i = i+1
  }
  # remove first row of no data
  G = cbind(x1,G[2:i,])
  G = data.frame(G)
  names(G) = names.of.G
  return(G)
}