# ***************************************************************************
# Name  		 	: createReferenceProfile.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Create Reference Profile
#'
#' This function creates the inventory profile of the reference site
#' adding several layers, from top (starting from 0) to bottom (negative values),
#' according to the distribution of the FRN Inventory and
#' considering a fixed layer thickness
#' @param FRNinv A list of FRN values
#' @param thickness The thickness of the layers (the same for all the layers)
#' @param name The name of the site
#' @param isotope The isotope code used as tracer
#' @param halfLife The time required for a quantity of the isotope to reduce to half its initial value
#' @param falloutTime A character representing the date-time of fall-out
#' @param refTime A character representing the date-time of sampling
#' @param timeFormat A character representing the date-time format (default \%Y-\%m-\%d)
#' @param massDepth The area density of the soil (in kg m^-2)
#' @return A new FRN depth profile object (class "Inventory")
#' @examples
#' myRP = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),
#'                               3, 'Reference site 1')
#' @export

createReferenceProfile <- function(FRNinv,thickness,name,
                                   isotope = NA,halfLife = NA, falloutTime = NA,
                                   refTime = NA,timeFormat = '%Y-%m-%d',
                                   massDepth = NA){
  #FRNinv = FRNinv/thickness
  # always tranform to a data.frame
  FRNinv = data.frame(FRNinv)
  n.FRN = dim(FRNinv)[1]
  max.depth = n.FRN*thickness

  zup = seq(0,-max.depth+thickness,-thickness)
  zdown = seq(-thickness,-max.depth,-thickness)

  RDF = Inventory(zup,zdown,FRNinv, name, origin = 'measured',
                  isotope, halfLife,falloutTime,
                  refTime, timeFormat,
                  massDepth)
  return(RDF)
}
