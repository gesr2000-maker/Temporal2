# ***************************************************************************
# Name        : summary.MODERN.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Reports statistics from MODERN output
#'
#' Reports some statistics (number of layer, min and max depth, min and max FRN)
#' of a MODERN object
#' @param x An object of class MODERN
#' @examples
#'
#' @export

summary.MODERN <- function(x,...){
  sols = unique(as.numeric(x$solution[!is.na(x$solution)]))
  if (length(sols)>0){
    b = boxplot(as.numeric(sols),plot = F)
    nOfSolutions = b$n
    nOfOutliers = length(b$out)
    solStat = data.frame(t(b$stats))
    minSol = min(sols)
    maxSol = max(sols)
    meanSol = mean(sols)
    sdSol = sd(sols)
  } else{
    nOfSolutions = 0
    nOfOutliers = NA
    solStat = data.frame(matrix(rep(NA,5, ncol = 5)))
    minSol = min(sols)
    maxSol = max(sols)
    meanSol = mean(sols)
    sdSol = sd(sols)
  }

  names(solStat) = c('Q1-1.5r','Q1','Q2','Q3','Q3+1.5r')
  res = list(nOfSolutions,nOfOutliers,minSol, maxSol,meanSol,sdSol,solStat)
  res
}
