# ***************************************************************************
# Name  		 	: addPloughedLayers.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Mix layers
#'
#' This function allows you to replace several layers with one with uniform value.
#' @param RDF A Reference Depth Profile object (class "Inventory")
#' @param newvalue The new value assigned to the new layers. If NULL, use the mean of the replaced layers (default = NULL))
#' @param NumLay The number of layers that composed the deposition depth
#' @param DEBUG Print intermediate results (default is False)
#' @return A new Reference Depth Profile object (class "Inventory")
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' plot(myRDF)
#' myRDF.plo = addPloughedLayers(myRDF,NULL,2)
#' plot(myRDF.plo)
#' @export

addPloughedLayers <- function(RDF, newvalue = NULL, NumLay = 1, DEBUG = F){
  # if newvalue is NULL, use the mean of the replaced layers
  if (is.null(newvalue)){
    d = dim(RDF$FRN)
    if (d[2]>1) {
      newvalue = apply(RDF$FRN[1:NumLay,],2,mean)
    } else {
      newvalue = mean(RDF$FRN[(n-NumLay+1):n,1])
    }
  } else newvalue = newvalue
  # get the layer thickness
  thickness = abs(RDF$Layers$zup[1]-RDF$Layers$zdown[1])
  # get absolute upper limit
  zmax = max(RDF$Layers$zup)

  for (i in seq(1,NumLay,1)){
    RDF = SetLayer(RDF, zmax-(i-1)*thickness,
                   zmax-i*thickness,
                   newvalue, 'ploughed')
  }
  RDF
}
