# ***************************************************************************
# Name    	 	: print.MODERN.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Print MODERN data
#'
#' Default display function for MODERN class object
#' @param x An object of class MODERN
#' @param maxNumOfResults The maximum number of results to be shown, otherwise print statustics (default = 10)
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' mySL = createSamplingProfile(68,10,'mysite')
#' myMOD = MODERN(myRDF,mySL)
#' print(myMOD)
#' @export

print.MODERN <- function(x, ...){
  cat("MODERN simulation results in length unit:\n")
  print(x$solution,...)

  if ((!is.na(x$sampProfile$massDepth)) &
     (!is.na(x$sampProfile$refTime)) &
     (!is.na(x$sampProfile$falloutTime)))
     {
       res = yearlyEDRates(x,
                           massDepth = x$sampProfile$massDepth,
                           sampleDepth = GetLayerThickness(x$sampProfile),
                           samplingTime = x$sampProfile$refTime,
                           falloutTime = x$sampProfile$falloutTime,
                           timeFormat = x$sampProfile$timeFormat)

      cat("\n Erosion rate(s) (t yr^-1 ha^-1)\n")
      print(res,...)
    } else{
      wmsg = "Cannot calculate erosion rate(s) beacuse one or more parameters of the sampling profile is NA"
      warning(wmsg, call. = TRUE, immediate. = FALSE, noBreaks. = FALSE,
              domain = NULL)
  }
  cat("\nIntermediate results are accessible through these slots:\n")
  cat(paste(names(x), collapse='; '))


}
