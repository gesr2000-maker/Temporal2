# ***************************************************************************
# Name    	 	: computeCumG.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Compute the cumulative function of G
#'
#' This function allows you to compute the cumulative function of a piecewise linear function G.
#' @param Inv An inventory object
#' @return A dataframe with the average layer depths and the cumulative values
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' cumtable = .computeCumG(myRDF)
#' print(cumtable)
#' @keywords internal

computeCumG <- function(Inv){
  # Commment:
  # calc cumulative function
  zup <- Inv$Layers$zup
  zdown <- Inv$Layers$zdown
  FRN <- Inv$FRN

  # calc reference depth, the first point is the uppest limit
  zref = c(zup[1],zdown)
  # calc cumulative function, the first element is zero
  delta = abs(zup-zdown)
  zeros = rep(0,length(FRN[1,]))
  #FRN = rbind(zeros,FRN*delta)
  FRN = rbind(zeros,FRN)
  FRNcum = apply(FRN,2,cumsum)
  cumG = cbind(zref,FRNcum)
  return(cumG)
}
