# ***************************************************************************
# Name        : print.summary.Inventory.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Print statistics
#'
#' Print some statistics (number of layer, min and max depth, min and max FRN)
#' of the inventory profile in readable way.
#' @param x An object of class Inventory
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' s= summary(myRDF)
#' print(s)
#' @export


print.summary.Inventory <- function(x,...){
  cat("Name of the profile:\n")
  print(x$Name)
  cat("\nStatistics:\n")
  print(paste('Num. of layer:',x$len))
  print(paste('Max depth:',x$zmin))
  print(paste('Min depth:',x$zmax))
  print(paste('Max FRN:',x$FRNmax))
  print(paste('Min FRN:',x$FRNmin))
}
