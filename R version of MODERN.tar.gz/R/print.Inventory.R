# ***************************************************************************
# Name        : print.Inventory.R
# Description : Part of the modeRn package
# Date        : 9/May/16
# copyright   : (C) 2016 by Enrico A. Chiaradia
# email       : enrico.chiaradia@yahoo.it
# credits     :
# https://umweltgeo.unibas.ch/forschung/aktuelle-projekte/soil-erosion-assessment-with-radionuclides/
# ***************************************************************************
#
# ***************************************************************************
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU General self.License as published by    *
# *   the Free Software Foundation; either version 2 of the License, or     *
# *   (at your option) any later version.                                   *
# *                                                                         *
# ***************************************************************************

#' Print reference depth profile data
#'
#' Default display function for Inventory class object
#' @param x An object of class Inventory
#' @examples
#' myRDF = createReferenceProfile(c(14.27,29.83,20.21,12.39,6.28),3, 'Reference')
#' print(myRDF)
#' @export

print.Inventory <- function(x,...){
  cat("Name of the reference depth profile:\n")
  print(x$Name)
  cat("\nLayers:\n")
  print(x$Layers)
  cat("\nTotal FRN inventory (Bq m^-2):\n")
  print(sapply(x$FRN,sum))
  cat("\nMean layer thickness:\n")
  print(GetLayerThickness(x))
  cat("\n === Metadata ===\n")
  cat("\nIsotope:\n")
  print(x$Isotope)
  cat("\nHalf-life:\n")
  print(x$halfLife)
  cat("\nreference date-time:\n")
  print(x$refTime)
  cat("\nMass depth of the sampling site (kg m^-2):\n")
  print(x$massDepth)
}
